import express from "express"
import cors from "cors"
import mongoose from "mongoose"


const app = express()
app.use(express.json())
app.use(express.urlencoded())
app.use(cors())

mongoose.connect("mongodb://localhost:27017/myLoginRegisterDB", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}, () => {
    console.log("Db Connected")
})

// app.post("/signup" ,(req , res)=>{
//     //res.send("shivam kumar")
//     console.log(req.body)
// })
const userSchema = new mongoose.Schema({
    name: String,
    email: String,
    password: String
})

const User = new mongoose.model("User", userSchema)
//Route
app.post("/login", (req, res) => {
    const { email, password } = req.body
    User.findOne({ email: email }, (err, user) => {
        if (user) {
            if (password === user.password) {
                res.send({ message: "login Successfully", user: user })
            } else {
                res.send({ message: "password did not match " })
            }
        } else {
            res.send({ message: "User not registerd" })
        }
    })
})

app.post("/signup", (req, res) => {
    //console.log(req.body)
    const { name, email, password } = req.body
    User.findOne({ email: email }, (err, user) => {
      //  console.log("fsdhgf")
        if (user) {
            res.send({ message: "User already registerd" })
        } else {
            const user = new User({
                name,
                email,
                password
            })
            user.save(err => {
                if (err) {
                    res.send({ message: "you are not registerd" })
                } else {
                    res.send({ message: "successfully registerd" })
                }
            })
        }
    })
})

app.listen(9002, () => {
    console.log("Be started at port 9002")
})

